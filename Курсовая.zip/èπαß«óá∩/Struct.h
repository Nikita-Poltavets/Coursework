#pragma once
#include "Lib.h"

struct pod_otdel{
	
	char name_otdel[40];
	int amount_otdel;

};

struct spec {

	int amount_spec;
};
struct cname{
	char name_spec[30];

};

struct sname{
	char name_semya[40];
	int child;
	int kategor;
	int viplati;
	int cchild;

};


struct semya{
	int amount_semya;
};