#pragma once
#include <vector>
#include <string>
#include <stdint.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <math.h>
#include <fstream>
#include <ctime>
#include <windows.h>
#include <conio.h>
#include <cstdlib>
using namespace std;
